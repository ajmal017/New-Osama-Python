# pandas-technical-indicators
Technical Indicators implemented in Python using Pandas.

# Source
Indicators as shown by Peter Bakker at:

    https://www.quantopian.com/posts/technical-analysis-indicators-without-talib-code

# Looking for a proper python library?

Have a look at @peerchemist's [finta](https://github.com/peerchemist/finta) library!
